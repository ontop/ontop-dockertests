--
-- PostgreSQL database dump
--

-- Dumped from database version 9.1.24
-- Dumped by pg_dump version 9.3.1
-- Started on 2017-03-06 18:26:00 CET

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- TOC entry 1935 (class 1262 OID 1086654)
-- Name: geosparql; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE geosparql WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


\connect geosparql

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- TOC entry 169 (class 3079 OID 11677)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 1937 (class 0 OID 0)
-- Dependencies: 169
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--Add the PostGIS extensions
CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


SET search_path = public, pg_catalog;

SET default_with_oids = false;

--
-- TOC entry 168 (class 1259 OID 1096429)
-- Name: Features; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "Features" (
    id integer NOT NULL,
    gid text,
    the_geom geometry,
    name text
);


--
-- TOC entry 1926 (class 0 OID 1086673)
-- Dependencies: 164
-- Data for Name: Features; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO "Features" (id, gid, the_geom, name) VALUES (1, 'France', 'POINT(2.2945 48.8584)', 'Eiffel Tower');
INSERT INTO "Features" (id, gid, the_geom, name) VALUES (2, 'UK1', 'POINT(-0.0754 51.5055)', 'Tower Bridge');


--
-- TOC entry 1821 (class 2606 OID 1096436)
-- Name: features_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "Features"
    ADD CONSTRAINT features_pk PRIMARY KEY (id);



-- Completed on 2017-03-06 18:26:00 CET

--
-- PostgreSQL database dump complete
--

