CREATE DATABASE nested WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';

\connect nested;

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;


CREATE SCHEMA hr;

CREATE TABLE "hr"."person-xt" (
    id integer NOT NULL,
    ssn integer,
    fullname character varying,
    tags json,
    friends json
);


ALTER TABLE hr."person-xt" OWNER TO postgres;


INSERT INTO hr."person-xt" VALUES (1,
123,
'Mary Poppins',
'[111, 222, 333]',
'[
{ "fname": "Alice",
"nickname": "Al",
"address": {
"city": "Bolzano",
"street": "via Roma",
"number": "33"
}},
{ "fname": "Robert",
"nickname": "Bob",
"address":
{"city": "Merano",
"street": "via Dante",
"number": "23"
}}]');


INSERT INTO hr."person-xt" VALUES
(2,
1234,
'Roger Rabbit',
'[111, 222]',
'{ "fname": "Mickey", "lname": "Mouse"}'
);

ALTER TABLE ONLY "hr"."person-xt"
    ADD CONSTRAINT "person-xt_pk" PRIMARY KEY (id);
