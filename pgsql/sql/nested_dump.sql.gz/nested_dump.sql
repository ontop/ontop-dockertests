CREATE DATABASE nested WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';

\connect nested;

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;


CREATE SCHEMA hr;

CREATE TABLE "hr"."person-xt" (
    id integer NOT NULL,
    ssn integer,
    fullname character varying,
    tags json,
    friends json
);


ALTER TABLE hr."person-xt" OWNER TO postgres;

ALTER TABLE ONLY "hr"."person-xt"
    ADD CONSTRAINT "person-xt_pk" PRIMARY KEY (id);

INSERT INTO hr."person-xt" VALUES (1,
123,
'Mary Poppins',
'[111, 222, 333]',
'[
{ "fname": "Alice",
"nickname": "Al",
"address": {
"city": "Bolzano",
"street": "via Roma",
"number": "33"
}},
{ "fname": "Robert",
"nickname": "Bob",
"address":
{"city": "Merano",
"street": "via Dante",
"number": "23"
}}]');


INSERT INTO hr."person-xt" VALUES
(2,
1234,
'Roger Rabbit',
'[111, 222]',
'{ "fname": "Mickey", "lname": "Mouse"}'
);


INSERT INTO hr."person-xt" VALUES 
(3,
23,
'Bob Loblaw',
NULL,
'[]'
);


INSERT INTO hr."person-xt" VALUES 
(4,
24,
'Kenny McCormick',
'[]',
NULL
);


CREATE SCHEMA pub;


CREATE TABLE "pub"."person" (
    id integer NOT NULL,
    name character varying,
    publication json,
    contribs json
);

ALTER TABLE pub."person" OWNER TO postgres;

ALTER TABLE ONLY "pub"."person"
    ADD CONSTRAINT "person_pk" PRIMARY KEY (id);

INSERT INTO pub."person" VALUES (
	1,
    'Sanjay Ghemawat',

'[
  { "title": "The Google file system",
    "id": 1,
    "year": 2003,
    "venue":"SOSP",
    "editor": [
      {"name":  "M. Scott"},
      {"name":  "L. Peterson"}
    ]
  },
  { "title": "Bigtable: A Distributed Storage System for Structured Data",
    "id": 2,
    "year": 2008,
    "venue":"ACM TOCS" ,
    "editor": [
      {"name": "M. Swift"}
    ]
  },
  { "title": "MapReduce: Simplified Data Processing on Large Clusters",
    "id": 3,
    "year": 2004,
    "venue":"OSDI",
    "editor": [
      {"name": "E. Brewer"},
      {"name": "P. Chen"}
    ]
  }
]'
	,
'[
    {"value": "Google File System"},
    {"value": "MapReduce "},
    {"value": "Bigtable "},
    {"value": "Spanner "}
]'
);


INSERT INTO pub."person" VALUES (
	2,
'Jeffrey Dean',
  '[
    { "title": "Bigtable: A Distributed Storage System for Structured Data",
      "id": 2,
      "year": 2008,
      "venue":"ACM TOCS",
      "editor": [
        {"name": "M. Swift"}
      ]
    },
    { "title": "MapReduce: Simplified Data Processing on Large Clusters",
      "id": 3,
      "year": 2004,
      "venue":"OSDI",
      "editor": [
        {"name": "E. Brewer"},
        {"name": "P. Chen"}
      ]
    },
    { "title": "Large Scale Distributed Deep Networks",
      "id": 4,
      "year": 2012,
      "venue":"NeurIPS",
      "editor": [
        {"name":  "P. Bartlett"},
        {"name":  "F. Pereira"},
        {"name":  "C. Burges"},
        {"name":  "L. Bottou"},
        {"name":  "K. Weinberger "}
      ]
    }
  ]'
,
'[
    {"value": "MapReduce "},
    {"value": "Bigtable "},
    {"value": "Spanner "},
    {"value": "TensorFlow "}
 ]'
);

